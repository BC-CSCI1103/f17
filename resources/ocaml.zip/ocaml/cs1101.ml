(* file: CS1101.ml 
 * author: Bob Muller
 * date: September 9, 2015
 *
 * Various helper functions for CS1101.
 * compile as in:
 *
 * > ocamlfind ocamlc -package universe -a -o cs1101.cma cs1101.ml
 *)

let randomColor () =
  let red   = Random.int 256 in
  let green = Random.int 256 in
  let blue  = Random.int 256
  in
  Color.make_color red green blue

(* Abbreviations *)
		   
let i2S = string_of_int
let i2F = float_of_int
	   
let f2S = string_of_float
let f2I = int_of_float
	   
let ps = print_string
let pc = print_char
let pi = print_int
let pf = print_float
  
