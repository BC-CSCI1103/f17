(* file: stddraw.ml
   author: Bob Muller
   date: September 8, 2014

   version 0.1

   dependencies: graphics.cma

   This is an implementation of the stddraw library. The stddraw library is 
   very loosely based on Sedgewick & Wayne's library of the same name. It 
   has been adapted from a python (2.7) library implemented by Pine Wu.

   This library specifies functions/procedures for drawing simple shapes
   in the unit square. The lower-left is at (x, y) coordinates (0.0, 0.0) 
   and the upper right is at (1.0, 1.0).
*)

(*
 This implementation is built-on OCaml's Graphics module.
*)
type color = Graphics.color

(*
 State variables.
*)
let xSize = ref 600;;
let ySize = ref 600;;
let lineWidth = ref 2;;

let makePicture () =
  let xs = string_of_int !xSize in
  let ys = string_of_int !ySize in
  let _ = Graphics.open_graph (" " ^ xs ^ "x" ^ ys) in
    Graphics.set_line_width (!lineWidth);;

let clear () = Graphics.clear_graph();;

let scaleX xUnit = 
  let xS = float_of_int (!xSize) in
    int_of_float(xUnit *. xS);;

let scaleY yUnit = 
  let yS = float_of_int (!ySize) in
    int_of_float(yUnit *. yS);;

let line x0 y0 x1 y1 =
  let x0s = scaleX x0 in
  let y0s = scaleY y0 in
  let x1s = scaleX x1 in
  let y1s = scaleY y1 in
  let _ = Graphics.moveto x0s y0s in
    Graphics.lineto x1s y1s;;
  
let arc x y rx ry a1 a2 = 
  let (xs, ys) = (scaleX x, scaleY y) in
  let (rxs, rys) = (scaleX rx, scaleY ry) in
    Graphics.draw_arc xs ys rxs rys a1 a2;;
  
let filledArc x y rx ry a1 a2 color = 
  let (xs, ys) = (scaleX x, scaleY y) in
  let (rxs, rys) = (scaleX rx, scaleY ry) in
  let oldColor = Graphics.foreground in
  let _ = Graphics.set_color color in
  let _ = Graphics.fill_arc xs ys rxs rys a1 a2 in
    Graphics.set_color oldColor;;

(* 
 circle x y radius draws a circle centered at (x, y), of the given radius.
*)
let circle x y radius = 
  let (xs, ys) = (scaleX x, scaleY y) in
  let rs = scaleX radius in                (* This is bogus. *)
    Graphics.draw_circle xs ys rs;;

(*
 filledCircle x y radius color draws the same figure as circle except 
 the circle has a color.
*)
let filledCircle x y radius color = 
  let (xs, ys) = (scaleX x, scaleY y) in
  let rs = scaleX radius in
  let oldColor = Graphics.foreground in
  let _ = Graphics.set_color color in
  let _ = Graphics.fill_circle xs ys rs in
  let _ = Graphics.set_color Graphics.black in
  let _ = Graphics.draw_circle xs ys rs in
    Graphics.set_color oldColor;;


(* 
 circle x y radius draws a circle centered at (x, y), of the given radius.
*)
let rectangle x y width height = 
  let (xs, ys) = (scaleX x, scaleY y) in
  let (ws, hs) = (scaleX width, scaleY height) in
    Graphics.draw_rect xs ys ws hs;;

(*
 filledCircle x y radius color draws the same figure as circle except 
 the circle has a color.
*)
let filledRectangle x y width height color = 
  let (xs, ys) = (scaleX x, scaleY y) in
  let (ws, hs) = (scaleX width, scaleY height) in
  let oldColor = Graphics.foreground in
  let _ = Graphics.set_color color in
  let _ = Graphics.fill_rect xs ys ws hs in
  let _ = Graphics.set_color Graphics.black in
  let _ = Graphics.draw_rect xs ys ws hs  in
    Graphics.set_color oldColor;;

(* Colors *)

let black = Graphics.black
let white = Graphics.white
let red = Graphics.red
let green = Graphics.green
let blue = Graphics.blue
let yellow = Graphics.yellow
let cyan = Graphics.cyan
let magenta = Graphics.magenta

let makeColor red green blue = Graphics.rgb red green blue

let randomColor () =
  let red = Random.int 255 in  
  let green = Random.int 255 in  
  let blue = Random.int 255 in
    makeColor red green blue;;

let set_line_width width = 
  Graphics.set_line_width width;;
